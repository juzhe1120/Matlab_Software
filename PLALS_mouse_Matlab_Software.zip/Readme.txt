This MATLAB software package is used to simultaneously predict lysine acetylation sites and lysine succinylation sites in mouse proteins.

Usage of this MATLAB software package:

(1) Prepare your sequence(s) file in fasta format and name it "Xinput.fasta";

(2) Run the program "PLALS_ mouse.m";

(3) Get the result file "Pre_result.xls".

Please note that this software package only supports the 32-bit version of Windows operating system.

If you have any questions, please contact us. 

Email: juzhe1120@hotmail.com