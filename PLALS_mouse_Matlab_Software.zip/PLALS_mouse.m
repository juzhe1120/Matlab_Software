clc
clear

Data_preprocessing  % Data preprocessing and CKSAAP feature extracting

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Predicting %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('Model.mat') % 'Model.mat' includes six SVM models which have been trained by 10-fold cross-validation.
load('Feature.mat') % 'Feature.mat' includes six optimal CKSAAP feature sets; 

class1=0;
class2=0;
class3=0;
class4=0;
testlabel=ones(size(test_data,1),1); % testlabel can be randomly assigned

  testdata=test_data(:,Feature1);% F-score feature selection
  [predict_label1, accuracy1,dec_values1] = svmpredict(testlabel, testdata, model1); % classifier1 predicting
  predict_label=predict_label1;
  predict_label(predict_label<0)=0;
  class1=class1+predict_label;
  predict_label=predict_label1;
  predict_label(predict_label>=0)=0;
  class2=class2-predict_label;
  clc
  
  testdata=test_data(:,Feature2);% F-score feature selection
  [predict_label2, accuracy2,dec_values2] = svmpredict(testlabel, testdata, model2);% classifier2 predicting
  predict_label=predict_label2;
  predict_label(predict_label<0)=0;
  class1=class1+predict_label;
  predict_label=predict_label2;
  predict_label(predict_label>=0)=0;
  class3=class3-predict_label;
  clc
  
  testdata=test_data(:,Feature3);% F-score feature selection
  [predict_label3, accuracy3,dec_values3] = svmpredict(testlabel, testdata, model3);% classifier3 predicting
  predict_label=predict_label3;
  predict_label(predict_label<0)=0;
  class1=class1+predict_label;
  predict_label=predict_label3;
  predict_label(predict_label>=0)=0;
  class4=class4-predict_label;
  clc
  
  testdata=test_data(:,Feature4);% F-score feature selection
  [predict_label4, accuracy4,dec_values4] = svmpredict(testlabel, testdata, model4);% classifier4 predicting
   predict_label=predict_label4;
  predict_label(predict_label<0)=0;
  class2=class2+predict_label;
  predict_label=predict_label4;
  predict_label(predict_label>=0)=0;
  class3=class3-predict_label;
  clc
  
  testdata=test_data(:,Feature5);% F-score feature selection
  [predict_label5, accuracy5,dec_values5] = svmpredict(testlabel, testdata, model5);% classifier5 predicting
   predict_label=predict_label5;
  predict_label(predict_label<0)=0;
  class2=class2+predict_label;
  predict_label=predict_label5;
  predict_label(predict_label>=0)=0;
  class4=class4-predict_label;
  clc
  
  testdata=test_data(:,Feature6);% F-score feature selection
  [predict_label6, accuracy6,dec_values6] = svmpredict(testlabel, testdata, model6);% classifier6 predicting
   predict_label=predict_label6;
  predict_label(predict_label<0)=0;
  class3=class3+predict_label;
  predict_label=predict_label6;
  predict_label(predict_label>=0)=0;
  class4=class4-predict_label;
  clc
  
 Class=[class1 class2+0.1 class3+0.2 class4+0.3]; % simple majority vote of the six SVM classifiers
 [max_a, index] = max(Class');
 predict_label=index';
%disp(['Note that the above results are meaningless !!!']);   
%The output results are meaningless, because the testlabel are randomly assigned
disp(['The prediction results have been saved to result file "Pre_result.xls".']);

%%%%%%%%%%%%%%%%%%%%%%%%%%%% Prediction over %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%% The predicted results output %%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:size(test_data,1)
    ID(i,1)=result1{i,1};
    position(i,1)=result1{i,2};
end
  
 B=[1  -1 ; -1	 1 ;1	1 ;-1  -1];
for i=1:4
II=find(predict_label==i);
T=repmat(B(i,:),size(II,1),1);
Pre_Labels(II,:)=T;              %Transform lable 1 to  (1, -1)'; 2 to (-1,1)'; 3 to (1,1)'; 4 to (-1,-1)'.
end

A1=[{'Uniprot AC'} {'Lysine_position'} {'Acetyllysine?'} {'Succinyllysine?'}];
B1=[{''} {''} '(Yes:1, No:-1)' '(Yes:1, No:-1)'];
aa=[];
for i=1:size(test_data,1)
   a= {ID{i,1} position(i,1) Pre_Labels(i,1) Pre_Labels(i,2)};
   aa=[aa ;a];
end
aaa=[A1;B1;aa];
xlswrite('Pre_result.xls', aaa);
winopen('Pre_result.xls');  %Open the result file "Pre_result.xls".
clear all