clc
clear

Data_preprocessing  % Data preprocessing and CKSAAP feature extraction

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Predicting %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('MODEL') 
% 'MODEL.mat' includes the two .mat files: 'Feature.mat' and 'model.mat'.
% 'Feature.mat' includes a optimal CKSAAP feature set; 
% 'model.mat' includes a BSVM model which have been trained in jackknife test.
testdata=test_data(:,Feature);  % F-score feature selection
testlabel=ones(size(test_data,1),1); % testlabel can be randomly assigned
[predict_label, accuracy,dec_values] = svmpredict(testlabel, testdata, model); % predicting 
clc
Pre_score=dec_values;
disp(['The prediction results have been saved to result file "Pre_result.xls".']);

%%%%%%%%%%%%%%%%%%%%%%%%%%%% Prediction over %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%% The predicted results output %%%%%%%%%%%%%%%%%%%%%%%%%%%

 for i=1:size(test_data,1)
      ID(i,1)=result1{i,1};
      position(i,1)=result1{i,2};
 end
  
A1=[{'Uniprot AC'} {'Lysine_position'} {'Phosphoglycerylation?'} {'SVM_score'}];
B1=[{''} {''} '(Yes:1, No:-1)' '(Higher SVM scores indicate more reliable phosphoglycerylation sites)'];
aa=[];
for i=1:size(test_data,1)
   a= {ID{i,1} position(i,1) predict_label(i,1) Pre_score(i,1)};
   aa=[aa ;a];
end
aaa=[A1;B1;aa];
xlswrite('Pre_result.xls', aaa);
winopen('Pre_result.xls');  %Open the result file "Pre_result.xls".
clear all